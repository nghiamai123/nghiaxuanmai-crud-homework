<?php
/**
 * Connect to database
 */
function db() {

}

/**
 * Create new student record
 */
function createStudent($value) {

}

/**
 * Get all data from table student
 */
function selectAllStudents() {

}

/**
 * Get only one on record by id 
 */
function selectOnestudent($id) {

}

/**
 * Delete student by id
 */
function deleteStudent($id) {

}


/**
 * Update students
 * 
 */
function updateStudent($firstName, $LastName) {

}
